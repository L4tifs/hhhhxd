export class Membre {
    constructor(
        public id:string,
        public firstName:string,
        public lastName:string,
        public role:string,
        public image:string,
        public linkdin:string
    ){}
}
