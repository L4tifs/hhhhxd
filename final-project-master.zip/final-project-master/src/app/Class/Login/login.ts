export class Login {
    constructor(
        public id:number,
        public username:string,
        public password:string
    ){}
}
