import { Component } from '@angular/core';

@Component({
  selector: 'app-contenair',
  templateUrl: './contenair.component.html',
  styleUrls: ['./contenair.component.css']
})
export class ContenairComponent {

}
