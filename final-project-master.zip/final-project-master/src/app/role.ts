export enum Role {
    Chef = "Team Lead",
    TechnicalLead ="Technical Lead",
    Developpeur="Developper"
}